// eslint-disable-next-line no-undef
module.exports = {
  proseWrap: "always",
};
