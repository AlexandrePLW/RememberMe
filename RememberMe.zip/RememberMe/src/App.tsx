import { useState } from 'react';
import { ConnectButton, useCurrentAccount, useSuiClientQuery } from '@mysten/dapp-kit';
import { FaRegImages, FaMapMarkerAlt, FaRegClock, FaRegIdBadge, FaStar } from 'react-icons/fa';
import { BsStars } from "react-icons/bs";
import { useSignAndExecuteTransaction } from '@mysten/dapp-kit';
import { Transaction } from '@mysten/sui/transactions';

// Sui Move contract constants
const PACKAGE_ID = '0x95638c7bf351d39f47d0870da4023759c3fc678bd512596ed94f16b4b0909090'; 
const MODULE_NAME = 'memory';
const FUNCTION_NAME = 'mint_memory';
const SUI_CLOCK_ID = '0x6';

/**
 * Contextual confirmation modal for minting a new memory NFT.
 * Shows memory details and asks the user to confirm or cancel.
 * If not connected, displays an error message.
 */
function ConfirmModal({ open, onConfirm, onCancel, memoryName, memoryUrl, memoryLocation, memoryDescription, notConnectedMsg }: {
    open: boolean;
    onConfirm: () => void;
    onCancel: () => void;
    memoryName: string;
    memoryUrl: string;
    memoryLocation: string;
    memoryDescription: string;
    notConnectedMsg?: string;
}) {
    if (!open) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
            <div
                className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full border flex flex-col gap-4"
                style={{ borderColor: "#E9DCC3", color: "#7C5C3B", backgroundColor: "#FDF6ED" }}
            >
                <h2 className="text-xl font-bold mb-2 text-center">Confirm memory creation</h2>
                <div className="flex flex-col gap-2 items-center text-[#7C5C3B]">
                    <div className="flex items-center gap-2">
                        <span className="font-semibold">Name:</span>
                        <span>{memoryName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold">Image:</span>
                        <img
                            src={memoryUrl}
                            className="inline h-10 w-10 object-cover rounded"
                            style={{ background: "#FFF8E7" }}
                        />
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold">Location:</span>
                        <span>{memoryLocation}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold">Description:</span>
                        <span>{memoryDescription}</span>
                    </div>
                </div>
                {/* Error message if not connected */}
                {notConnectedMsg && (
                    <div className="text-red-600 text-center text-m mt-2">{notConnectedMsg}</div>
                )}
                <div className="flex justify-end gap-4 mt-6">
                    <button
                        className="px-4 py-2 rounded bg-[#E9DCC3] text-[#7C5C3B] font-semibold hover:bg-[#f3e5d0] transition"
                        onClick={onCancel}
                    >
                        Cancel
                    </button>
                    <button
                        className="px-4 py-2 rounded bg-[#7C5C3B] text-white font-semibold hover:bg-[#a68b6a] transition"
                        onClick={onConfirm}
                    >
                        Confirm
                    </button>
                </div>
            </div>
        </div>
    );
}


/**
 * Custom React hook to mint a new memory NFT and handle pending state.
 */
function useSaveNewMemory() {
    const { mutate: signAndExecute } = useSignAndExecuteTransaction();
    const [pending, setPending] = useState(false);

    const save = (memoryName: string, memoryUrl: string, memoryLocation: string, memoryDescription: string, onSuccess?: () => void, onError?: (e: any) => void) => {
        setPending(true);
        const tx = new Transaction();
        tx.moveCall({
            target: `${PACKAGE_ID}::${MODULE_NAME}::${FUNCTION_NAME}`,
            arguments: [
                tx.object(SUI_CLOCK_ID),
                tx.pure.string(memoryName),
                tx.pure.string(memoryUrl),
                tx.pure.string(memoryLocation),
                tx.pure.string(memoryDescription),
            ],
        });

        signAndExecute(
            { transaction: tx },
            {
                onSuccess: () => {
                    setPending(false);
                    onSuccess && onSuccess();
                },
                onError: (error) => {
                    setPending(false);
                    onError && onError(error);
                },
            }
        );
    };

    return { save, pending };
}

/**
 * Handles the check-in flow:
 * - Detects if the user is on a /checkin/ route with memory data in the URL.
 * - Shows the confirmation modal with memory details.
 * - If confirmed and connected, mints the NFT.
 * - If not connected, shows an error message in the modal.
 */
function CheckinHandler() {
    const [modalOpen, setModalOpen] = useState(false);
    const [memoryData, setMemoryData] = useState<{ name: string, url: string, location: string, description: string } | null>(null);
    const [notConnectedMsg, setNotConnectedMsg] = useState<string | undefined>(undefined);
    const { save } = useSaveNewMemory();
    const account = useCurrentAccount();

    // 1. Get the full URL
    const url = typeof window !== "undefined" ? new URL(window.location.href) : null;

    // 2. Extract memory data from the /checkin/ path (base64 encoded)
    let memoryName = "", memoryUrl = "", memoryLocation = "", memoryDescription = "";
    if (url) {
        const pathSegments = url.pathname.split('/');
        memoryName = pathSegments[pathSegments.length - 4];
        memoryUrl = pathSegments[pathSegments.length - 3];
        memoryLocation = pathSegments[pathSegments.length - 2];
        memoryDescription = pathSegments[pathSegments.length - 1];
    }

    // If on /checkin/ and data is present, open the modal (only once)
    if (
        memoryName && memoryUrl && memoryLocation && memoryDescription &&
        url && url.pathname.includes('/checkin/') &&
        !memoryData // avoid infinite loop
    ) {
        setMemoryData({
            name: atob(memoryName),
            url: atob(memoryUrl),
            location: atob(memoryLocation),
            description: atob(memoryDescription),
        });
        setModalOpen(true);
    }

    // Show the confirmation modal if needed
    return (
        <ConfirmModal
            open={modalOpen}
            memoryName={memoryData?.name || ""}
            memoryUrl={memoryData?.url || ""}
            memoryLocation={memoryData?.location || ""}
            memoryDescription={memoryData?.description || ""}
            notConnectedMsg={notConnectedMsg}
            onCancel={() => {
                setModalOpen(false);
                setNotConnectedMsg(undefined);
            }}
            onConfirm={() => {
                // If not connected, show error message
                if (!account) {
                    setNotConnectedMsg("You must be connected to confirm this memory.");
                    return;
                }
                // If connected, mint the NFT
                if (memoryData) {
                    save(
                        memoryData.name,
                        memoryData.url,
                        memoryData.location,
                        memoryData.description,
                        () => {
                            setModalOpen(false);
                            setNotConnectedMsg(undefined);
                        }
                    );
                }
            }}
        />
    );
}

// Default location (Paris)
const DEFAULT_LOCATION = { lat: 48.8584, lng: 2.2945 }; 
const MAIN_BROWN = "#FDF6ED"; // Main brown/cream color for the app

/**
 * Main application component.
 * Renders header, check-in handler, main content, and footer.
 */
function App() {
    return (
        <div className="min-h-screen" style={{ backgroundColor: MAIN_BROWN }}>
            <CheckinHandler />
            <Header />
            <main className="flex-1 w-full px-2 sm:px-8 md:px-32 py-12 flex flex-col items-center justify-center">
                <ConnectedAccount />
            </main>
            <footer className="w-full py-4 text-center text-[#7C5C3B] bg-[#FDF6ED] border-t border-[#E9DCC3] text-sm">
                © {new Date().getFullYear()} RememberMe — Built with ❤️ on Sui
            </footer>
        </div>
    );
}

/**
 * Application header with logo and wallet connect button.
 */
function Header() {
    return (
        <header className="w-full shadow-md border-b" style={{ backgroundColor: MAIN_BROWN, borderColor: "#E9DCC3" }}>
            <div className="max-w-7xl mx-auto px-4 sm:px-8 flex items-center justify-between h-20">
                <div className="flex items-center gap-3">
                    <BsStars className="text-3xl" style={{ color: "#7C5C3B" }} />
                    <span className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: "#7C5C3B" }}>RememberMe</span>
                </div>
                <div className="flex items-center gap-4">
                    <ConnectButton />
                </div>
            </div>
        </header>
    );
}

/**
 * Shows the connected wallet address, or a prompt to connect if not connected.
 * Renders the user's NFT timeline if connected.
 */
function ConnectedAccount() {
    const account = useCurrentAccount();

    if (!account) {
        return (
            <div className="mt-24 text-[#7C5C3B] text-2xl text-center flex flex-col items-center gap-6 animate-fade-in">
                <FaRegImages className="text-6xl drop-shadow" style={{ color: "#7C5C3B" }} />
                <span className="font-semibold">Connect your wallet to view your NFT memories.</span>
            </div>
        );
    }

    return (
        <div
            className="rounded-2xl p-8 w-full max-w-5xl mx-auto border shadow-xl animate-fade-in"
            style={{ backgroundColor: MAIN_BROWN, borderColor: "#E9DCC3", color: "#7C5C3B" }}
        >
            <div className="mb-8 flex flex-col items-center">
                <span className="text-lg font-semibold mb-2" style={{ color: "#7C5C3B" }}>Connected as</span>
                <div className="font-mono break-all text-base rounded px-3 py-2 inline-block" style={{ backgroundColor: "#F5E9D7", color: "#7C5C3B" }}>
                    {account.address}
                </div>
            </div>
            <OwnedObjects address={account.address} />
        </div>
    );
}

/**
 * Displays the user's NFT timeline as a vertical timeline.
 * Each memory is shown with its image, name, date, description, and a button to view its location on a map.
 */
function OwnedObjects({ address }: { address: string }) {
    const { data, isLoading } = useSuiClientQuery('getOwnedObjects', {
        owner: address,
        options: { showContent: true },
    });

    const [selectedMemory, setSelectedMemory] = useState<null | { id: string }>(null);

    // Loading state
    if (isLoading) {
        return (
            <div className="text-[#7C5C3B] mt-4 text-lg flex items-center gap-3 animate-pulse">
                <FaRegImages className="text-2xl" style={{ color: "#7C5C3B" }} />
                Loading your memories…
            </div>
        );
    }
    // No NFTs found
    if (!data || !data.data.length) {
        return (
            <div className="text-[#7C5C3B] mt-4 text-lg flex items-center gap-3">
                <FaRegImages className="text-2xl" style={{ color: "#7C5C3B" }} />
                No memories found.
            </div>
        );
    }

    // Utility to get a static map image URL for given coordinates
    const getStaticMapUrl = (lat: number, lng: number) =>
        `https://static-maps.yandex.ru/1.x/?lang=en-US&ll=${lng},${lat}&z=13&l=map&size=450,300&pt=${lng},${lat},pm2rdm`;

    // Filter only objects of type "memory"
    const filteredData = data.data.filter(
        (object) => object.data?.content?.fields?.type_of_memory === "memory"
    );

    // Sort memories by date (newest first)
    const sortedData = [...filteredData].sort((a, b) => {
        const dateA = Number(a.data?.content?.fields?.date || 0);
        const dateB = Number(b.data?.content?.fields?.date || 0);
        return dateB - dateA; // from the last to the newest
    });

    return (
        <div className="w-full mt-2">
            <h2 className="text-2xl font-bold mb-10 text-center tracking-tight flex items-center justify-center gap-3" style={{ color: "#7C5C3B" }}>
                <FaRegImages className="text-[#7C5C3B]" />
                NFT Memories Timeline
            </h2>
            <div className="relative pl-8">
                {/* Timeline vertical line */}
                <div className="absolute left-4 top-0 bottom-0 w-1 rounded-full opacity-70" style={{ backgroundColor: "#E9DCC3" }} />
                <div className="flex flex-col gap-12">
                    {sortedData.map((object) => (
                        <div
                            key={object.data?.objectId}
                            className="relative group cursor-pointer rounded-xl border shadow hover:shadow-lg transition-shadow duration-200 p-6 flex flex-col md:flex-row items-center animate-fade-in"
                            style={{ backgroundColor: MAIN_BROWN, borderColor: "#E9DCC3", color: "#7C5C3B" }}
                            onClick={() => setSelectedMemory({ id: object.data?.objectId ?? '' })}
                            title="Show memory location"
                        >
                            {/* Timeline dot with star icon */}
                            <div className="absolute -left-12 top-6 md:top-1/2 md:-translate-y-1/2 flex items-center justify-center">
                                <div className="h-6 w-6 rounded-full border-4 shadow flex items-center justify-center" style={{ backgroundColor: "#E9DCC3", borderColor: MAIN_BROWN }}>
                                    <FaStar className="text-xs" style={{ color: "#7C5C3B" }}/>
                                </div>
                            </div>
                            {/* Memory image */}
                            <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-8">
                                <img
                                    src={object.data?.content?.fields?.url}
                                    alt="Memory"
                                    className="h-24 w-24 rounded-xl border-4 shadow bg-white object-cover"
                                    style={{ borderColor: "#E9DCC3" }}
                                />
                            </div>
                            {/* Memory content */}
                            <div className="flex-1 flex flex-col gap-2 w-full">
                                <div className="flex items-center gap-3 mb-1">
                                    <span className="text-xl font-bold" style={{ color: "#7C5C3B" }}>
                                        {object.data?.content?.fields?.name}
                                    </span>
                                </div>
                                <div className="flex flex-wrap items-center gap-4 text-base" style={{ color: "#7C5C3B" }}>
                                    <span className="flex items-center gap-1">
                                        <FaRegClock className="mr-1" style={{ color: "#BFA074" }} />
                                        <span className="italic">{object.data?.content?.fields?.date ? new Date(Number(object.data.content.fields.date)).toLocaleString() : ""}</span>
                                    </span>
                                    <span className="flex items-center gap-1">
                                        <FaRegIdBadge className="mr-1" style={{ color: "#BFA074" }} />
                                        <span className="font-mono text-xs rounded px-2 py-0.5" style={{ backgroundColor: "#F5E9D7", color: "#7C5C3B" }}>{object.data?.objectId}</span>
                                    </span>
                                </div>
                                <div className="text-sm mt-1" style={{ color: "#A68B6A" }}>
                                    {object.data?.content?.fields?.description}
                                </div>
                            </div>
                            {/* Button to show the memory location on a map */}
                            <div className="w-full md:w-auto mt-4 md:mt-0 md:ml-8 flex justify-end md:justify-center">
                                <button
                                    className="flex items-center gap-2 px-4 py-2 rounded-full text-sm shadow font-semibold transition focus:outline-none focus:ring-2 max-w-full"
                                    style={{
                                        backgroundColor: "#E9DCC3",
                                        color: "#7C5C3B",
                                        wordBreak: 'keep-all',
                                        whiteSpace: 'nowrap'
                                    }}
                                    onClick={e => {
                                        e.stopPropagation();
                                        setSelectedMemory({ id: object.data?.objectId ?? '' });
                                    }}
                                >
                                    <FaMapMarkerAlt className="mr-1" style={{ color: "#7C5C3B" }} />
                                    Show on map
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            {/* Modal to show the static map for the selected memory */}
            {selectedMemory && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 animate-fade-in">
                    <div className="bg-white rounded-2xl shadow-2xl p-8 relative w-full max-w-xl" style={{ borderColor: "#E9DCC3" }}>
                        <button
                            className="absolute top-3 right-3 text-3xl font-bold"
                            style={{ color: "#BFA074" }}
                            onClick={() => setSelectedMemory(null)}
                            aria-label="Close map"
                        >
                            ×
                        </button>
                        <h3 className="text-2xl font-bold mb-4 flex items-center gap-2" style={{ color: "#7C5C3B" }}>
                            <FaMapMarkerAlt className="mr-1" style={{ color: "#BFA074" }} />
                            Memory location
                        </h3>
                        <div className="w-full flex justify-center">
                            <img
                                src={(() => {
                                    // Get coordinates from the memory object, fallback to default
                                    const memoryObj = filteredData.find(obj => obj.data?.objectId === selectedMemory.id);
                                    const loc = memoryObj?.data?.content?.fields?.location;
                                    const [lat, lng] = loc ? loc.split(',').map((v: string) => parseFloat(v.trim())) : [DEFAULT_LOCATION.lat, DEFAULT_LOCATION.lng];
                                    return getStaticMapUrl(lat, lng);
                                })()}
                                alt="Memory map"
                                className="rounded-xl border shadow-lg"
                            />
                        </div>
                        <div className="mt-4 text-sm break-all text-center" style={{ color: "#A68B6A" }}>
                            Memory ID: {selectedMemory.id}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default App;